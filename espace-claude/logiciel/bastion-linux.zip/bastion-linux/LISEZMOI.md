# Bastion — pare-feu personnel pour Linux

Pare-feu à interface moderne inspiré de **Look 'n' Stop** : règles ordonnées, filtrage par application,
filtrage par **adresse MAC**, bibliothèque de règles, zones, journal, profils, mot de passe, et un menu
**Aide** avec des exemples de ports ouverts/fermés et d'applications autorisées/bloquées (ajout en un clic).

Bastion pilote le pare-feu intégré du système (nftables) : il y envoie des règles validées,
avec confirmation et retour arrière automatique.

## Lancer
`./lancer_linux.sh` (utilise sudo). Prérequis : **Python 3.8+** et `nftables` (`sudo apt install nftables`).
Facultatif : `sudo apt install python3-psutil` (liste des connexions plus riche).

L'interface s'ouvre dans votre navigateur (`http://127.0.0.1:<port>/`). Sans droits administrateur,
Bastion démarre en **mode simulation** (tout marche sauf l'application réelle des règles).

## Utilisation en 3 temps
1. Créez ou importez des règles (*Filtrage Internet*, bouton *Bibliothèque*).
2. **Appliquer** (en haut à droite).
3. **Confirmer** sous 30 s, sinon l'état précédent revient seul. *Aperçu des commandes* montre ce qui sera exécuté.

## Spécificités Linux
- Filtrage **par compte utilisateur** (en sortie) et non par programme : lancez une application sous un compte dédié, puis bloquez ce compte.
- Règles évaluées de haut en bas, la première qui correspond décide.
- Les règles sont perdues au redémarrage : installez `extras/bastion.service` (systemd) ou lancez `sudo python3 pare_feu.py --apply` au démarrage.
- Pas d'alertes « nouveau programme » ni de drapeaux TCP.

## Filtrage par adresse MAC
Champ « Adresse MAC de l'appareil distant » d'une règle (format AA:BB:CC:DD:EE:FF, réseau local uniquement).
**En entrée**, l'adresse MAC de l'émetteur est comparée directement (`ether saddr`, fiable). **En sortie**, elle est convertie en adresse(s) IP d'après la table de voisinage (`ip neigh`) au moment d'« Appliquer ».

## Sécurité de l'application
Serveur local `127.0.0.1` uniquement, jeton aléatoire par lancement, contrôle de l'en-tête `Host`, protection anti-CSRF,
validation stricte de tous les champs, aucune commande passée par un shell. Configuration : `/var/lib/bastion/config.json` (root)

## En cas de perte de connexion
Attendez la fin du compte à rebours sans confirmer, ou *Tableau de bord → Désactiver Bastion*. Dernier recours : `sudo nft delete table inet bastion`

## Tests
`python3 tests/test_engine.py`
