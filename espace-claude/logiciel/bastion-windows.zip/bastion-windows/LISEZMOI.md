# Bastion — pare-feu personnel pour Windows

Pare-feu à interface moderne inspiré de **Look 'n' Stop** : règles ordonnées, filtrage par application,
filtrage par **adresse MAC**, bibliothèque de règles, zones, journal, profils, mot de passe, et un menu
**Aide** avec des exemples de ports ouverts/fermés et d'applications autorisées/bloquées (ajout en un clic).

Bastion pilote le pare-feu intégré du système (Pare-feu Windows Defender, via netsh/PowerShell) : il y envoie des règles validées,
avec confirmation et retour arrière automatique.

## Lancer
Double-clic sur **`lancer_windows.bat`** (il demande les droits administrateur). Prérequis : **Python 3.8+**.
`psutil` est installé automatiquement (liste des connexions et alertes).
Option : `build_exe_windows.bat` fabrique un `Bastion.exe` autonome.

L'interface s'ouvre dans votre navigateur (`http://127.0.0.1:<port>/`). Sans droits administrateur,
Bastion démarre en **mode simulation** (tout marche sauf l'application réelle des règles).

## Utilisation en 3 temps
1. Créez ou importez des règles (*Filtrage Internet*, bouton *Bibliothèque*).
2. **Appliquer** (en haut à droite).
3. **Confirmer** sous 30 s, sinon l'état précédent revient seul. *Aperçu des commandes* montre ce qui sera exécuté.

## Spécificités Windows
- Filtrage **par programme** (chemin complet de l'exécutable).
- Un blocage l'emporte toujours sur une autorisation, quel que soit l'ordre : Bastion le signale.
- Alertes « nouveau programme » : détectées après sa première connexion (pas d'interception en temps réel).
- Les règles restent actives après redémarrage.
- Pas de filtrage par compte utilisateur ni de drapeaux TCP.

## Filtrage par adresse MAC
Champ « Adresse MAC de l'appareil distant » d'une règle (format AA:BB:CC:DD:EE:FF, réseau local uniquement).
Windows ne sait pas filtrer les MAC : Bastion convertit l'adresse en **adresse(s) IP actuelle(s)** d'après la table ARP (`arp -a`) au moment d'« Appliquer ». L'appareil doit être présent sur le réseau ; réappliquez si son IP change.

## Sécurité de l'application
Serveur local `127.0.0.1` uniquement, jeton aléatoire par lancement, contrôle de l'en-tête `Host`, protection anti-CSRF,
validation stricte de tous les champs, aucune commande passée par un shell. Configuration : `%ProgramData%\Bastion\config.json`

## En cas de perte de connexion
Attendez la fin du compte à rebours sans confirmer, ou *Tableau de bord → Désactiver Bastion*. Dernier recours : `netsh advfirewall reset`

## Tests
`python3 tests/test_engine.py`
